#pragma once

#include <Arduino.h>
#include <helpers/ESP32Board.h>

// ESP32-C3 Super Mini + RA-02 SX1278
// No battery ADC and no Heltec-specific hardware are assumed.
class C3Board : public ESP32Board {
public:
  void begin() {
    ESP32Board::begin();
    startup_reason = BD_STARTUP_NORMAL;
  }

  const char* getManufacturerName() const override {
    return "ESP32-C3 Super Mini";
  }

  // SX1278 DIO0 is the radio interrupt used by the MeshCore SX1276 wrapper.
  uint32_t getIRQGpio() override {
    return P_LORA_DIO_0;
  }
};
