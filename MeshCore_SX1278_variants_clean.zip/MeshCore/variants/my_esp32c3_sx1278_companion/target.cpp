#include <Arduino.h>
#include <SPI.h>
#include "target.h"

C3Board board;

// Use Arduino's global SPI bus, matching the tested ESP32-C3 + RA-02 setup.
RADIO_CLASS radio = new Module(
    P_LORA_NSS,
    P_LORA_DIO_0,
    P_LORA_RESET,
    P_LORA_DIO_1
);

WRAPPER_CLASS radio_driver(radio, board);

ESP32RTCClock fallback_clock;
AutoDiscoverRTCClock rtc_clock(fallback_clock);
SensorManager sensors;

bool radio_init() {
  fallback_clock.begin();
  rtc_clock.begin(Wire);
  return radio.std_init(&SPI);
}

mesh::LocalIdentity radio_new_identity() {
  RadioNoiseListener rng(radio);
  return mesh::LocalIdentity(&rng);
}
