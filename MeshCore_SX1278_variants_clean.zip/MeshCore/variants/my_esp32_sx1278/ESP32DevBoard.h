#pragma once

#include <Arduino.h>
#include <helpers/ESP32Board.h>

// Generic classic ESP32 DevKit board used with an external RA-02 SX1278.
class ESP32DevBoard : public ESP32Board {
public:
  void begin() {
    ESP32Board::begin();
    startup_reason = BD_STARTUP_NORMAL;
  }

  const char* getManufacturerName() const override {
    return "ESP32 DevKit";
  }

  uint32_t getIRQGpio() override {
    return P_LORA_DIO_0;
  }
};
